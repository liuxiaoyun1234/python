print(type(int('23')))

print(isinstance(234,str))