# p2_1.py
temp = input("不妨猜一下小甲鱼心在心里想的是什么数字")
guess = int(temp)
if guess == 8:
    print("你是小甲鱼的蛔虫吗")
    print("猜对了")
else:
    print("猜错了")
print("game over")
