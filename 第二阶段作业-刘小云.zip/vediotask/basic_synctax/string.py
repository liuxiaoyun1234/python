string = "test"
number = 1

print(string.title())
print(string.upper())
print(string.lower())

print("\t"+string)
print(string.rstrip())
print(string.lstrip())

print(string.strip())
print(str(number))