
tupleT1 = (0,1,2,3,4,'Apple')
print(tupleT1[5])