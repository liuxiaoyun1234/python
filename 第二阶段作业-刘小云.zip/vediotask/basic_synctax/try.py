try:
    file = open("eee","r+")
except Exception as e:
    print("there is no file named as eee")