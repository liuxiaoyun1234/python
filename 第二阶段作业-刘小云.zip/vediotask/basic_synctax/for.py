listT1 = ['apple','banana','cake','dog']
for x in listT1:
    print(x)

for z in range(1,5):
    print(z)

for z in range(1,11,2):
    listT1.append(z**2)

print(listT1)

print(listT1[:])

print(listT1[:3])