import time
print(time.localtime())


import time as t
print(t.localtime())

from time import localtime,time
print(localtime())
print(time())

from time import *
print(localtime())